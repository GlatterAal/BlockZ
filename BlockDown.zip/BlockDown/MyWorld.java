import greenfoot.*;
import java.util.*;
public class MyWorld extends World
{
    int i;
    Line lines;
    boolean isGameActive;
    int speed;
    PlayerBlock pB;
    public MyWorld()
    {    
        super(250, 500, 1,false);
        drawBg();
        setPaintOrder(Line.class);
        i=0;
        isGameActive=true;
        speed=2;
    }
    public void act(){
        if(isGameActive){
            this.placeLines(); 
        }
    }
    public void placeLines(){
        if(i==0){
            pB=new PlayerBlock();
            this.addObject(pB,125,25);
            this.addObject(new Line(), 30, 560);
            i++;
        }else{
            List<Block> k=getObjectsAt(25, 475, Block.class);
            if(!k.isEmpty()){
                int x=k.get(0).getY();
                if(x==475){
                    this.addObject(new Line(), 30, 560);
                }
            }
        }
    }
    public void drawBg(){
        GreenfootImage img = new GreenfootImage(300,100);//Create Greenfoot image
        img.setColor(Color.BLACK);//Add Background Color
        img.fill();//Fill Backgrounds
        setBackground(img);
    }
    public void moveLines(){
        
        
    }
    public void deleteAllLines(){
        List<Line> lines=this.getObjects(Line.class);
        for(Line l:lines){
            l.deleteLine();
        }
    }
    public void resetPlayer(){
        pB.setLocation(125, 25);
    }
}

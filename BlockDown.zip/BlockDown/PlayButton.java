import greenfoot.*;
import java.util.*;
public class PlayButton extends Actor
{
    public PlayButton(){
        
    }
    public void act(){
        
    
    }
}

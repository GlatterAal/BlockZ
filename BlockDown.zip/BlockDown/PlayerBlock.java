import greenfoot.*;
import java.util.*;
public class PlayerBlock extends Actor
{
    long lastAdded=System.currentTimeMillis();
    int i;
    ArrayList<Color> colors;
    Color color;
    public PlayerBlock(){
        this.colors = new ArrayList<Color>();
        this.setColor();
        this.getImg(this.color);
        i=0;
    }
    public void act()
    {
        MyWorld myworld = (MyWorld) getWorld();
        if(myworld.isGameActive){
            this.checkColor();
            if(i==8){
                this.checkMovement();
                i=0;
            }
            this.move(myworld.speed);
            i++;
            this.swapColor(this.getRandomInterval(2000,4000));
        }
    }
    public int getRandomInterval(int start,int end)
    {
       int normal = Greenfoot.getRandomNumber(end-start+1);
       return normal+start;
    }
    public void swapColor(int frequenz){
        long curTime=System.currentTimeMillis();
        if(curTime>=this.lastAdded +frequenz){
            int size= Greenfoot.getRandomNumber(6);
            int transperancy= this.getRandomInterval(100,200);
            int x= Greenfoot.getRandomNumber(500);
            this.setColor();
            this.getImg(this.color);
            this.lastAdded  = curTime;
        }
    }
    public void setColor(){
        colors.add(Color.RED);
        colors.add(Color.BLUE);
        colors.add(Color.ORANGE);
        colors.add(Color.MAGENTA);
        colors.add(Color.GREEN);
        Collections.shuffle(colors);
        this.color=colors.get(0);
    }
    public void checkColor(){
        World w=getWorld();
        List<Block> k=w.getObjectsAt(this.getX(), this.getY()+25, Block.class);
        if(!k.isEmpty()){
            Block b= k.get(0);
            if(b.getColor()==this.color){
                b.removeLine();
                
                //    this.setLocation(this.getX(), this.getY()+50);
                
                
            }
        }
    }
    public void checkMovement(){
        if(Greenfoot.isKeyDown("left")){
            if(this.getX()!=25){
                for(int i=0;i<50;i++){
                    this.setLocation(this.getX()-1, this.getY());
                }
            }
        }
        if(Greenfoot.isKeyDown("right")){
            if(this.getX()!=225){
                for(int i=0;i<50;i++){
                    this.setLocation(this.getX()+1, this.getY());
                }
            }
        }
    }
    public void move(int speed){
        World w=getWorld();
        List<Block> k=w.getObjectsAt(this.getX(), this.getY()+25, Block.class);
        
        if(!k.isEmpty()){
            this.setLocation(this.getX(),this.getY()-speed);
        }else{
            if(this.getY()!=425){
                this.setLocation(this.getX(),this.getY()+speed);
            }
        }
    }
    public void getImg(Color color){
        GreenfootImage image = new  GreenfootImage(50, 50);
        image.setColor(color);
        image.fill();
        setImage(image);
    }
}
